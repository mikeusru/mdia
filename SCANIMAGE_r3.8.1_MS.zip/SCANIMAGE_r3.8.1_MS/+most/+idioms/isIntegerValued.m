function tf = isIntegerValued(x)
tf = mod(x,1)==0;
end