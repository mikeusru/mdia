%% NI DAQmx
apiCurrentVersion = '9.2.x';