function dumbCallbackFcn(~,~)
disp('howdy');
end