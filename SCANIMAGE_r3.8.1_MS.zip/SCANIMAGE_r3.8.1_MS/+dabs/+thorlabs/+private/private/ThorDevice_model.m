%% Thorlabs Devices
apiCurrentVersion = '1.4'; %One of {'1.4'}.