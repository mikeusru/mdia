function out = map8x24(angle,transpose)
% 8 x 24 array
% 192 elements

% algorithm for generating non-square rectangular maps:
% start with square map, e.g. 8x8, then
% concatenate N more squares, e.g. 2
%
% out = map8x8
% a = out+(out-1)*2
% b = a +1; c = a + 2;
% map8x32 = cat(1, a, b, c)

out = [
     1    97    25   121     7   103    31   127
   145    49   169    73   151    55   175    79
    37   133    13   109    43   139    19   115
   181    85   157    61   187    91   163    67
    10   106    34   130     4   100    28   124
   154    58   178    82   148    52   172    76
    46   142    22   118    40   136    16   112
   190    94   166    70   184    88   160    64
     2    98    26   122     8   104    32   128
   146    50   170    74   152    56   176    80
    38   134    14   110    44   140    20   116
   182    86   158    62   188    92   164    68
    11   107    35   131     5   101    29   125
   155    59   179    83   149    53   173    77
    47   143    23   119    41   137    17   113
   191    95   167    71   185    89   161    65
     3    99    27   123     9   105    33   129
   147    51   171    75   153    57   177    81
    39   135    15   111    45   141    21   117
   183    87   159    63   189    93   165    69
    12   108    36   132     6   102    30   126
   156    60   180    84   150    54   174    78
    48   144    24   120    42   138    18   114
   192    96   168    72   186    90   162    66
];

if transpose
    out=out';
end

switch angle
case 0 
case 90
    out=rot90(out);
case 180
    out=rot90(rot90(out));
case 270
    out=rot90(rot90(rot90(out)));
otherwise
end
