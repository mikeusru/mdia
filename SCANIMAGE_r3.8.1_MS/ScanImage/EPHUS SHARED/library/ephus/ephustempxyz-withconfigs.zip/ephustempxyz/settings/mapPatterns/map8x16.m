function out = map8x16(angle,transpose)
% 8 x 16 array
% 128 elements

% algorithm for generating non-square rectangular maps:
% start with square map, e.g. 8x8, then
% concatenate N more squares, e.g. 2
%
% see other rect maps for further details

out = [
     1    65    17    81     5    69    21    85
    97    33   113    49   101    37   117    53
    25    89     9    73    29    93    13    77
   121    57   105    41   125    61   109    45
     7    71    23    87     3    67    19    83
   103    39   119    55    99    35   115    51
    31    95    15    79    27    91    11    75
   127    63   111    47   123    59   107    43
     2    66    18    82     6    70    22    86
    98    34   114    50   102    38   118    54
    26    90    10    74    30    94    14    78
   122    58   106    42   126    62   110    46
     8    72    24    88     4    68    20    84
   104    40   120    56   100    36   116    52
    32    96    16    80    28    92    12    76
   128    64   112    48   124    60   108    44
];

if transpose
    out=out';
end

switch angle
case 0 
case 90
    out=rot90(out);
case 180
    out=rot90(rot90(out));
case 270
    out=rot90(rot90(rot90(out)));
otherwise
end
