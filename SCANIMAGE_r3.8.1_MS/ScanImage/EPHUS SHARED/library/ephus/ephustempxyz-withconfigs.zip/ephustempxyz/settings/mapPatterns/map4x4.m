function out = map4x4
% 4 x 4 array
% 16 elements

out = [ ...
    1	9	3	11;
    13	5	15	7;
    4	12	2	10;
    16	8	14	6];