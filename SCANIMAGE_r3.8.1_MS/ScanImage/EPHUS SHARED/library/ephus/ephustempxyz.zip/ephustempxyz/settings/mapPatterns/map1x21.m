function out = map1x21(angle,transpose)
% 8 x 8	array
% 64 elements
out = [1 6 11 16 21 3 8 13 18 5 10 15 20 2 7 12 17 4 9 14 19];
    
if transpose
    out=out';
end

switch angle
case 0 
case 90
    out=rot90(out);
case 180
    out=rot90(rot90(out));
case 270
    out=rot90(rot90(rot90(out)));
otherwise
end
