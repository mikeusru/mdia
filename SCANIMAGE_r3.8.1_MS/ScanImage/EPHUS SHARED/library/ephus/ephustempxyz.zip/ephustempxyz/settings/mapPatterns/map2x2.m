function out = map2x2
% 2 x 2 array
% 4 elements

out = [ ...
    1	3;
    4	2];