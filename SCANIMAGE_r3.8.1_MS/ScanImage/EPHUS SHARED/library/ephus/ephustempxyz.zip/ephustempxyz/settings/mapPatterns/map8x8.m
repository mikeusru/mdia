function out = map8x8(angle,transpose)
% 8 x 8	array
% 64 elements
out = [ ...
        1	33	9	41	3	35	11	43;
    49	17	57	25	51	19	59	27;
    13	45	5	37	15	47	7	39;
    61	29	53	21	63	31	55	23;
    4	36	12	44	2	34	10	42;
    52	20	60	28	50	18	58	26;
    16	48	8	40	14	46	6	38;
    64	32	56	24	62	30	54	22];

if transpose
    out=out';
end

switch angle
case 0 
case 90
    out=rot90(out);
case 180
    out=rot90(rot90(out));
case 270
    out=rot90(rot90(rot90(out)));
otherwise
end
