function addToAF()
%addToAF is called from makeFrameByStripes in order to add the current image
%to the AF structure and calculate the spine coordinates

global state af ua spc

if state.internal.usePage %do not run during page acq
   return;
end

if af.params.isAFon && af.params.useAcqForAF
    I = getLastAcqImage;
    if state.spc.acq.spc_takeFLIM %z slice counter is off with flim
        zSliceCounter=state.internal.zSliceCounter;
    else
        zSliceCounter=state.internal.zSliceCounter+1;
    end
%     disp(['addToAF', num2str(zSliceCounter)]);
    af.images(zSliceCounter,af.params.channel).image=I;
    af.position.af_list_rel_z(zSliceCounter)=af.frameRelZPosition;
    af.position.af_list_abs_z(zSliceCounter)=af.frameAbsZPosition;
end

end

