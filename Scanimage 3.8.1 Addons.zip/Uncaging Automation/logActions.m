function logActions
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here

global dia
[ST,~]=dbstack;
dia.log=ST;

end

